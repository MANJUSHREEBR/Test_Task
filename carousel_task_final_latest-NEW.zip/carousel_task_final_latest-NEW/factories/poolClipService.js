/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
   angular
           .module('app')
           .factory('poolClipService', function ($http, $q) {
        return {
            getModelInformation: function() {
                // the $http API is based on the deferred/promise APIs exposed by the $q service
                // so it returns a promise for us by default
                return $http.get('model/model.json')
                    .then(function(response) {
                        if (typeof response.data === 'object') {
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject(response.data);
                        }

                    }, function(response) {
                        // something went wrong
                        return $q.reject(response.data);
                    });
            }
        };
    });
    






//(function() {
//    'use strict';
//
//    angular
//        .module('app')
//        .service('poolClipService',poolClipService);
//     
//         poolClipService.$inject =  ['$scope','$http', '$q'];
//
//
//    function  poolClipService($scope,$http,$q) {
//        return {
//            getModelInformation: getModelInformation
//            
//        };
//
//        function getModelInformation() {
//            return $http.get('model/model.json')
//                    .then(function(response) {
//                        if (typeof response.data === 'object') {
//                            return response.data;
//                        } else {
//                            // invalid response
//                            return $q.reject(response.data);
//                        }
//
//                    }, function(response) {
//                        // something went wrong
//                        return $q.reject(response.data);
//                    });
//            
//        };
//
//        
//    }
//})();