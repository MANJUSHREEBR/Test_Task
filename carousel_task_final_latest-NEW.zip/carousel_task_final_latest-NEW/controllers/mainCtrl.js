/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('CarouselDemoCtrl',CarouselDemoCtrl);

    CarouselDemoCtrl.$inject =  ['$scope','poolClipService'];
     
    function CarouselDemoCtrl($scope,poolClipService) {
     $scope.systemInfo={};
     $scope.slides=[
    {
      image: 'images/image1.jpg',
      image1:'images/not1.jpg'

    },
    {
      image: 'images/image2.jpg',
      image1:'images/not.jpg'

    },
    {
      image: 'images/image3.jpg',
      image1:'images/images.jpg'

    },
    {
      image: 'images/image4.jpg',
      image1:'images/images.jpg'

    },
    {
      image: 'images/image5.jpg',
      image1:'images/images.jpg'

    },
    {
    image: 'images/image6.jpg',
    image1:'images/images.jpg'

    },
    {
      image: 'images/image7.jpg',
     image1:'images/images.jpg'

    },
    {
      image: 'images/image8.jpg',
       image1:'images/images.jpg'

    }
   ];
   
   
 poolClipService.getModelInformation()
         .then(function(data) {
                    // promise fulfilled
                    console.log(data);
                    $scope.systemInfo.sys=data;
                     
                }, function(error) {
                    // promise rejected, could log the error with: console.log('error', error);
                    console.log('error', error);
                });

    
}

})();








