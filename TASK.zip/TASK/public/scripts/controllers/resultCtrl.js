(function(){
	'use strict' ;
	
	angular
	.module('contactModule')
	.controller("resultCtrl",resultCtrl);
	
	resultCtrl.$inject=['$scope','$http', '$filter','$rootScope'];
	function resultCtrl($scope, $http, $filter, $rootScope){
		
		
    var orderBy = $filter('orderBy');

		$scope.loadbar= function() {
               var $modal = $('.js-loading-bar'),
               $bar = $modal.find('.progress-bar');
               $modal.modal('show');
               $bar.addClass('animate');
               setTimeout(function() {
                 $bar.removeClass('animate');
                 $modal.modal('hide');
                }, 1500); 
          }();
     
       $rootScope.allContact=$scope.allContact;
	


        $(".nav a").on("click", function(){
		   $(".nav").find(".active").removeClass("active");
		   $(this).parent().addClass("active");
		});
		
		

		
 }
	
	
})();