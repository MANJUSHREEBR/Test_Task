(function(){
	'use strict' ;
	
	angular
	.module('contactModule')

	.controller("formCtrl",formCtrl);
	
	
	formCtrl.$inject=['$scope','$http','$rootScope','$location'];
	function formCtrl($scope,$http,$rootScope, $location){
		
		
		
		$(".nav a").on("click", function(){
		   $(".nav").find(".active").removeClass("active");
		   $(this).parent().addClass("active");
		});	
  
 
        $scope.variab=false;
        $scope.addPhone=addPhone;
        $scope.toggle=toggle;
		$scope.getDetails=getDetails;
		$scope.updateInfo=updateInfo;
		$scope.setInputDate=setInputDate;
		$scope.update=false;
		$scope.addPhone=addPhone;
		$scope.resetForm=resetForm;
		$scope.remove=remove;
		$scope.load=load;
		$scope.edit=edit;
		$scope.showDetails=showDetails;
		$scope.details=["Mrs","Mr","Ms"];
		$scope.medias=["Google","Facebook","Friend"];
		var date1=new Date();
		$scope.startDate=(date1.getFullYear()-70) + '-' + ('0' + (date1.getMonth() + 1)).slice(-2) + '-' + ('0' + (date1.getDate())).slice(-2) ;
		$scope.endDate=(date1.getFullYear()-18) + '-' + ('0' + (date1.getMonth() + 1)).slice(-2) + '-' + ('0' + (date1.getDate())).slice(-2) ;
		$scope.getDetails();
        

		function updateInfo(){

				if	($scope.myFormFieldSet.email1.$error.invalid){
                     toastr.error('Invalid Email Address!');	

		        }
		       else if(localStorage.getItem("phoneValid")=="1"){
		  	        toastr.error('Invalid phone number!');	
		        }
			   else{
                    
                    $scope.update=false;
			  	    var data={};
					data['title']=$scope.title;
				    data['name']=$scope.name;
				    data['date']=$scope.date;
				    data['phone']=$scope.phone;
					data['phone1']=$scope.phone1;
					data['email1']=$scope.email1;
                    data['media']=$scope.media;  
					console.log(JSON.stringify(data));					
					
					 $('.new').css('background', 'white');
					 $('.new1').css('background', 'white');
          		    $http({
						method:'PUT',
						url:'/updateDetails',
						params: { id: $scope.u},
						data:JSON.stringify(data)
					}).
					success(function (response){				
						console.log(data);											
						
					});	
				    $scope.getDetails();
					$scope.resetForm();
				    toastr.success('Contact Details Updated successfully!');		
                   


			    }
			
			}
			
        function edit(u){
                  $('.new').css('background', 'pink');
                  $scope.u=u._id;
                  $scope.title=u.title;
                  $scope.date=u.date;
                  $scope.name=u.name;
                  $scope.update=true;
                  $scope.phone=u.phone;
                  if(u.phone1)
                  {
                  $scope.phone1=u.phone1;
                  $scope.variab=true;
                  $('.new1').css('background', 'pink');

                  }
                  $scope.email1=u.email1;
                  $scope.media=u.media;
                  $scope.setInputDate("#dateDefault");

          }

       function setInputDate(_id){
                 var _dat = document.querySelector(_id);
                 var dnew=$scope.date.toString();
                 var d1=dnew.substr(0, 10);
                
                 _dat.value = d1;
        };

        function toggle(){

              	$scope.variab=!$scope.variab;
          }
        function addPhone(){
                $scope.variab=true;

		}

        function showDetails(u){
                  $rootScope.allContact=u;
				  window.location="/#/viewContactInfo";
				  $('#linkHome').removeClass("active");
				  $('#linkResult').addClass("active");

		}
			

	    function remove(u){


	    	var r = confirm("Are You Sure You Want TO Delete This Details??");

	    	if(r){
                  
			$http({
				 method: "DELETE",
				 url: '/deleteDetails',		 
				 params: { id: u}
			  })
			.success(function(data){	
			   console.log(data);
			  
			
		    })
			.error(function(err){
				 console.log(err);
			});

                 
             $scope.getDetails();
			
           }


		}
		
		
		
		

		function resetForm(){
			      $scope.title="";
				   $scope.name="";
				   $scope.date="";
				   $scope.phone="";
				   $scope.phone1="";
				   $scope.email1="";
				   $scope.email2="";
				   $scope.media="";
				   $scope.myForm.$setPristine();


		}
		
		function getDetails(){

            $http({
				 method: "GET",
				 url: '/getDetails'			 
				 //params: { from: $rootScope.from, to:$rootScope.to }
			  })
			.success(function(data){	
			   console.log(data);
			   $scope.users=data;
			
		    })
			.error(function(err){
				 console.log(err);
			});
			

		}
		

		
		
		
		
		
		function load(){


		    if	($scope.myFormFieldSet.email1.$error.invalid){
                  toastr.error('Invalid Email Address!');	

		     }
		    else if(localStorage.getItem("phoneValid")=="1"){
		  	      toastr.error('Invalid phone number!');	
		    }
			 else{
			    
	                var data={};
					data['title']=$scope.title;
				    data['name']=$scope.name;
				    data['date']=$scope.date;
				    data['phone']=$scope.phone;
					data['phone1']=$scope.phone1;
					data['email1']=$scope.email1;
                    data['media']=$scope.media;  
				    console.log(JSON.stringify(data));					
					
				    $http({
						method:'POST',
						url:'/Detail',
						data:JSON.stringify(data)
					}).
					success(function (response){				
						console.log(data);											
						
					});	
				    $scope.getDetails();
				    $scope.resetForm();
				     toastr.success('Contact Details loaded successfully!');					
			}
		
		}
	 
	
}
	
})();