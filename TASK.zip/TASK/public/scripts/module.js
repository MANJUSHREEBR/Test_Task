(function(){
	'use strict';
	angular
	.module('contactModule',['ui.router'])
	.config(router);
	
	 router.$inject = ['$stateProvider', '$urlRouterProvider'];
	 function router($stateProvider, $urlRouterProvider){
		 
		 $urlRouterProvider.otherwise('/form');
		 
		 $stateProvider
		 .state('form',{
			   url: '/form',
			   controller:'formCtrl',
			 templateUrl:'./views/form.html'
			  
			
		 })
		 .state('viewContactInfo',{
			   url: '/viewContactInfo',
			   controller:'resultCtrl' ,
			 templateUrl:'./views/result.html' 
			 
		 })	;	
			  
	}		 
	
})();