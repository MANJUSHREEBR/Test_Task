'use strict';
var app=angular.module( 'contactModule' );

var PHONE_REGEXP = /^[(]{0,1}[0-9]{3}[)\.\- ]{0,1}[0-9]{3}[\.\- ]{0,1}[0-9]{4}$/;



app.directive('phone', function() {
    return {
        restrice: 'A',
        require: 'ngModel',
        link: function(scope, element, attrs, ctrl) {
            angular.element(element).bind('blur', function() {
                var value = this.value;
               // var errorFlag = true;
                if(PHONE_REGEXP.test(value)) {
                    // Valid input
                    console.log("valid phone number");
                     localStorage.setItem("phoneValid",0);
                    angular.element(this).next().next().css('display','none');  
                } else {
                    // Invalid input  
                    console.log("invalid phone number");
                    toastr.error("invalid phone number");
                    localStorage.setItem("phoneValid",1);
                   // errorFlag = false;
                    angular.element(this).next().next().css('display','block');
                   
                    /* 
                        Looks like at this point ctrl is not available,
                        so I can't user the following method to display the error node:
                        ctrl.$setValidity('currencyField', false); 
                    */                    
                }

          //  $model.$setValidity( 'invalid', errorFlag);
            });              
        }            
    }        
});
