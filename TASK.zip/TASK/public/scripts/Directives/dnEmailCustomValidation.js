'use strict';
 
angular.module( 'contactModule' )
 
  /**
  * Directives is used to validate the multiple emails
  */
  .directive(
    'dnEmailCustomValidation',
    function() {
      return {
        require: [ '^form', 'ngModel' ],
        link: function( $scope, $element, attrs, ctls ) {
          var $form = ctls.shift( ),
          $model = ctls.shift( ),
          validateMatch = function( ) {
            var errorFlag = true;
 
            // Email Validations
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            var emailIds = $model.$viewValue;
            if (emailIds != "") {
              var emailIdsArr = emailIds.split(",");
              angular.forEach( emailIdsArr, function( value, key ) {
                if (!re.test(value)) {
                  errorFlag = false;
                  return false;
                }
              } );
            }
 
            $model.$setValidity( 'invalid', errorFlag);
          };
 
          // Trigger a validation check
          $model.$viewChangeListeners.push( validateMatch );
        }
      };
    }
  );