var express = require('express');
var fs = require('fs') ;
var bodyParser = require('body-parser'); 
var app = express();
var path = require('path');

var dataStore=require('nedb');
db= {};
db.detail = new dataStore({filename:'detail'}); 

db.detail.loadDatabase();


app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true}));

app.post('/Detail', function (req, res) {
	console.log(req.body.title);
	console.log(req.body.name);
	console.log(req.body.date)
	console.log(req.body.phone);
	console.log(req.body.email1);
	console.log(req.body.media);
	//console.log(req.body.price);
	//console.log(req.body.airline);
	
		
	
		
	db.detail.insert({title:req.body.title , name:req.body.name ,date:req.body.date, phone:req.body.phone,phone1:req.body.phone1,email1:req.body.email1,media:req.body.media })
 
}); 


app.get('/getDetails',function(req,res){

		
	db.detail.find({}).exec(function(err,docs){
		// console.log('start');			
		 //console.log(docs);
		 res.send(docs);
	});
	
});   
app.delete('/deleteDetails',function(req,res){
	console.log(req.query);	
	console.log(req.query.id);	
	
	
	var id= req.query.id;
	
	
	db.detail.remove({_id:id}, {});

	
});   
app.put('/updateDetails',function(req,res){
		
	
	
	console.log(req.query);	
	console.log(req.query.id);	
	
	
	var id= req.query.id;
	
	
db.detail.update({_id : id}, {title:req.body.title , name:req.body.name ,date:req.body.date, phone:req.body.phone,phone1:req.body.phone1,email1:req.body.email1,media:req.body.media}, {});

	
});   
		 
app.listen(process.env.PORT || 8080);